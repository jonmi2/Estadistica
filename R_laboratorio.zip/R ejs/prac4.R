#ejemplo1 n=10, p=0.3 
#a)La probabilidad de que la variable tome el valor de 4. Es decir, P(X=4).
dbinom(4,10,0.3)
#b La probabilidad acumulada hasta llegar al valor de 4. Es decir, P(X≤4).
dbinom(4,10,0.3)+dbinom(3,10,0.3)+dbinom(2,10,0.3)+dbinom(1,10,0.3)+dbinom(0,10,0.3)
pbinom(4,10,0.3)

#ejemplo2 p=0.45 distribución geométrica
#a) La probabilidad de que la variable tome el valor de 3. Es decir, P(X=3).
dgeom(3,0.45)
#b) La probabilidad acumulada hasta llegar al valor de 3. Es decir, P(X≤3)
pgeom(3,0.45)

#ejemplo3 poisson landa=3
#a) La probabilidad de que la variable aleatoria tome el valor de 8. Es decir, P(X=8)
dpois(8,3)
#b) La probabilidad acumulada hasta llegar al valor de 8. Esto es, P(X≤8).
ppois(8,3)

#ejemplo4 binomial negativa p=0.78
#a) ¿Cuál es la probabilidad de tener que realizar 15 mediciones para registrar 10 correctas?
dnbinom(5,10,0.78)
#b) ¿Cuál es la probabilidad de tener que realizar al menos 15 mediciones para registrar 10 mediciones correctas?
1-pnbinom(4,10,0.78)

#ejemplo5 
dhyper(2,4,6,3)
#b) ¿Cuál es la probabilidad de obtener como máximo 2 bolas blancas?
phyper(2,4,6,3)
#¿Cuál es la probabilidad de obtener al menos 2 bolas blancas?
1-phyper(1,4,6,3)

#ejemplo plot 
x<-0:5
x
plot(x,dbinom(x,5,1/3),type="h")
plot(x,pbinom(x,5,1/3),type="s")


#continuas
#ejemplo1 uniforme a=10 b=40
punif(30,10,40)

#ejemplo2 exponencial beta=5
pexp(6,1/5)-pexp(4,1/5)

#ejemplo3 normal media=65.6 desvi=14.74
pnorm(60,65.6,14.74)
qnorm(1-0.121,65.6,14.74)
1-pnorm(45,65.6,14.74)


#curve
curve(dexp(x,1/3),from=0, to=10)
