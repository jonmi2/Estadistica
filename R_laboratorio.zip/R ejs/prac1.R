#ejercicio1
((1+2)/(3+4))^2
sqrt(exp(2)+log(3,2))
x<-c(1:21)
prod(x)

#ejercicio2
#a
x<-c(20.5,12.6,-23,-6.98,24,32.8,7,-8.6)
F<-c(3,4,2,6,5,7,4,9)
sumF<-sum(F)
f8<-F[8]/sumF
#b
#c
#d

#ejercicio3
#a
km<-c(31422,31801,32131,32691,33077,33514,33992)
#b
diff(km)
#da la diferencia entre el siguiente y actual
#c
mean(diff(km))
#media de la diff
mean(km)
#media de km

#ejercicio4
#a
x<-seq(0,1.2,length=20)
#b
length(x)
#c
max(x)
min(x)
#d
x[10]<-343
#e
x<-seq(1,20,1)
y<-exp(x)
#f
?plot
?hist
#g
plot(x)
plot(y)
#h
hist(x)

#ejercicio5
x<-seq(1,199,2)
length(x)
sort(x, decreasing = FALSE)
sort(x, decreasing = TRUE)

#ejercicio6
x<-seq(100,199,2)
plot(x,log(x))
plot(x,cos(x))

#ejercicio7
mean(x)
calmedia<-function(datos){
  if(length(datos)==0){return (NULL)}
  else{return(sum(datos)/length(datos))}
}
media<-calmedia(x)
cat("La media de la lista de números es:", media, "\n")

#ejercicio8
f<-function(x){sin((x^2)+(x^3))}
f(-3*3.14)
f(0)
x<-c(-3*3.14,-2*3.14,-3.14,0,3.14,2*3.14,3*3.14)
plot(x,f(x))

#ejercicio9
x<-seq(0,39,2)
length(x)
cua<-x*x
cub<-x*x*x
datos<-data.frame(x,cua,cub)
datos
write.table(datos, "C:\Users\jonmi\OneDrive\Escritorio\R ejs\numeros_pares.txt")#error

#ejercicio10
#a
mtcars
#b
manual<-mtcars[mtcars$am==1, ]
manual
#c
mayora21<-mtcars[mtcars$mpg>21, ]
mayora21
#d
manuymayora21<-mtcars[mtcars$am == 1 & mtcars$mpg>21, ]
manuymayora21
#e
tresklibras<-mtcars[mtcars$wt>3.000, ]
tresklibras
#f
peso<-mtcars$wt
peso
mean(peso)
#g
# Crear una matriz con las columnas de interés
matriz_datos <- mtcars[, c("hp", "mpg", "cyl")]
matriz_datos
# Calcular la media de cada columna utilizando apply()
medias <- apply(matriz_datos, 2, mean)

# Asignar nombres a los elementos del vector resultante
names(medias) <- c("Media_Potencia", "Media_Consumo", "Media_Cilindrada")

# El vector medias ahora contiene las medias de cada variable
print(medias)
