#practica2
#ejemplo1
grietas<-c(50,68,84,86,64,67,78,87,110,85,52,65,52,93,72,70,105,85,30,42,74,30,70,65,49)#Introducir datos
limites<-c(30,40,50,60,70,75,85,90,110,Inf)#Límite de cada intervalo
grietas.limite<-cut(grietas,limites,right=FALSE)#Como los intervalos han de ser abiertos por la derecha: right=F
grietas.limite
table(grietas.limite)
a<-as.data.frame(table(grietas.limite))#Hemos convertido la tabla en un marco de datos. Puede usarse solo “data.frame (...)”
a
Intervalos<-a$grietas.limite #Lo único que se ha hecho es crear un vector a partir de la primera columna del marco de datos con el nombre de “Intervalos”.
Frecuencia.abs<-a$Freq #Lo único que se ha hecho es crear un vector a partir de la segunda columna del marco de datos con el nombre de “Frecuencia.abs”.
sum(Frecuencia.abs)#Suma de todos los datos
Frecuencia.rel<-Frecuencia.abs/25#Cálculo de la frecuencia relativa (recordad que “25” es el número de datos de este ejercicio)
Frecuencia.abs.acum<-cumsum(Frecuencia.abs)#Suma acumulada de las frecuencias absolutas
Frecuencia.rel.acum<-cumsum(Frecuencia.rel)#Suma acumulada de las frecuencias relativas
data.frame(Intervalos,Frecuencia.abs,Frecuencia.abs.acum,Frecuencia.rel,Frecuencia.rel.acum)

#ejemplo2
datos<-c(1,1,1,2,3,3,1,2,2,1,3,1,1)
a <- table(datos) #Los datos se han ordenado en una tabla, para conocer la frecuencia absoluta de cada uno
a
barplot(a) #diagrama de barras
pie(a) #diagrama de sectores
hist(datos) #histograma

#ejemplo3
stem(grietas,scale=2) #Diagrama de tallos y hojas
stem(grietas,scale=1) #cuanto mayor sea el scale mayor es el número de intervalos

#ejemplo4
longitudes<- c(115,232,181,161,155,137,165,171,139,130,406)
hist(longitudes)
hist(longitudes,main="Histograma longitudes", xlab="Longitudes (cm)",ylab="Densidad", breaks=c(100,150,200,450),col="orange")#Histograma con amplitudes de intervalo diferentes


#ejemplo5
#5.1Calcule las medidas de tendencia central: Media, Mediana y Moda.
datos <- c(1,1,1,2,3,3,1,2,2,1,3,1,1)
summary(datos) # Resumen de los principales estadísticos del vector “datos"
mean(datos)#Media
median(datos)#Mediana
table(datos)#De este modo podemos observar cuál es el valor que más se repite (Moda) Como puede observarse, el valor 1 es el que más se repite y por lo tanto la moda.
Moda<-names(table(datos))[which(table(datos)==max(table(datos)))] #Otra forma de cálculo
Moda

#5.2Calcule las medidas de dispersión: Rango, Rango intercuartílico, Varianza, Desviación típica y Coeficiente de variación.
Rango<-max(datos)-min(datos)
Rango
IQR(datos, type=2)#Rango intercuartílico
quantile(datos,0.75,type=2)-quantile(datos,0.25,type=2)#Otra forma de calcular el RIC
var(datos)#Cuasivarianza
N <- length(datos)# Para calcular la varianza se ha de conocer el número de elementos en el vector
varianza <- var(datos)* (N-1)/N# De este modo, partiendo de la cuasivarianza calculamos la varianza
varianza
des.tip <- sqrt(varianza)#La desviación típica es la raíz cuadrada de la varianza
des.tip
CV<-des.tip/mean(datos)#Coeficiente de variación
CV

#5.3Calcule las medidas de posición: Cuartiles, Deciles, Percentiles y el Percentil 40.
quantile(datos,type=2)#Cálculo de todos los cuartiles
quantile(datos,probs=seq(0,1,0.1),type=2)#Cálculo de los deciles
quantile(datos,probs=seq(0,1,0.01),type=2)#Cálculo de los percentiles
quantile(datos,0.4,type=2)#Percentil 40 o cuarto decil


#EJERICICOS
#ejercicio1
#a
grosor<-c(1, 2, 3, 3, 2, 1, 2, 5, 2, 4, 4, 4, 5, 3, 2, 5, 3, 4, 1, 4, 2, 3, 1, 1, 2, 5, 3, 4, 1, 3)
a<-table(grosor)
a
data.frame(a)
a
data.frame(a)
a<-data.frame(a)
a
Frecabs<-a$Freq
Frecabs
grosores<-a$grosor
grosores
n<-sum(Frecabs)
n
frecrela<-Frecabs/n
frecabsacum<-cumsum(Frecabs)
frecrelaacum<-cumsum(frecrela)
data.frame(Frecabs,frecabsacum,frecrela,frecrelaacum)
#b
barplot(table(grosor),col="pink")
#c
pie(table(grosor), labels = c("muy fino","fino","mediano","grueso","molto grueso"))

#ejercicio2
#a
tensionroturaa<-read.table("C:/Users/jonmi/OneDrive/Escritorio/R ejs/tensionrotura.txt",header=T)
#b
tensionroturaa
#c
cms<-tensionroturaa$Tension_rotura.Tn.cm2.
cms
cms<-gsub(",", ".", cms)
cms<-as.numeric(cms)
cms
stem(cms,scale=1)
#d
limites<-seq(min(cms), max(cms)+0.2, 0.2)
limites
hist(cms, breaks = limites)
#e
cms
a<-table(cms)
a
a<-data.frame(a)
a
max<-max(a$Freq)
max
moda<-subset(a,Freq == max)
moda
median(cms)
mean(cms)
#f
rango<-max(cms)-min(cms)
rango
IQR(cms,type=2)
n<-length(cms)
varianza<-var(cms)*(n-1)/n
varianza
desvitip<-sqrt(varianza)
desvitip
cuasivarianza<-var(cms)
cuasivarianza
cuasidesvitip<-sqrt(cuasivarianza)
cuasidesvitip
CV<-desvitip/mean(cms)
CV
#g-percentiles
Q1<-quantile(cms,probs=0.25)
Q2<-quantile(cms,probs=0.5)
Q3<-quantile(cms,probs=0.75)
Q1
Q2
Q3

#ejercicio3
#a
torsiones<-c(33,21,32,44,35,22,40,36,22,37,20,37,42,31,23,44,32,30,44,44,42,35,40,36,32,31,37,43,24,40,25,30,26,35,33,41,25,44,36,27)
torsiones
n<-length(torsiones)
n
rg<-max(torsiones)-min(torsiones)
rg
amp<-rg/6
amp
limites<-seq(min(torsiones),max(torsiones),amp)
limites
a<-cut(torsiones,limites,right = FALSE,include.lowest = TRUE)
a
t<-table(a)
t
datos<-data.frame(t)
datos
clases<-datos$a
clases
fi<-datos$Freq
fi
FI<-cumsum(fi)
FI
hi<-fi/n
hi
HI<-cumsum(hi)
HI
tabla<-data.frame(clases,fi,FI,hi,HI)
tabla

#b
limites
hist(torsiones, main="histoooo",breaks=limites)

#c
media<-mean(torsiones)
media
t<-table(torsiones)
t
dat<-data.frame(t)
dat
dat<-dat[order(-dat$Freq),]
dat
moda<-dat[1,]$torsiones
moda
median(torsiones)
n
variiii<-var(torsiones)*(n-1)/n
variiii
desvi<-sqrt(variiii)
desvi


#ejercicio7


#b
limites<-c(10,20,30,40,60)
lim<-cut(limites,breaks=c(10,20,30,40,60),right = FALSE,include.lowest = TRUE)
lim
limi<-table(lim)
limi
ll<-data.frame(limi)
ll
lims<-ll$lim
fi<-c((10*2.2),(10*2.6),(10*0.6),(20*0.2))
fi
n<-sum(fi)
n
FI<-cumsum(fi)
FI
hi<-(fi/n)
hi
HI<-cumsum(hi)
HI
data.frame(lims,fi,FI,hi,HI)

#c
n
n/4




#ejercicio8
turis<-read.table("C:/Users/jonmi/OneDrive/Escritorio/R ejs/Turismos.txt",header=T)
turis
#b
gasolio<-turis$Turismos.Gasolina+turis$Turismos.Gas.oil
gasolio
mean(gasolio)
median(gasolio)
n<-length(gasolio)
sqrt(var(gasolio)*(n-1)/n)
#c
vecs<-turis$Turismos.Gasolina+turis$Turismos.Gas.oil+turis$Turismos.Otros
vecs
dt<-data.frame(turis$PROVINCIAS,vecs)
dt
dt<-dt[order(dt$vecs),]
dt
dt<-dt[1:21,]
dt
provs<-dt$turis.PROVINCIAS
provs
