#ejemplo1
datos<-c(1,1,1,2,3,3,1,2,2,1,3,1,1)
datos
library(moments)
skewness(datos)
pearson<-(mean(datos)-1)/des.tip #Recordad que la moda es 1
pearson
kurtosis(datos)-3

#ejemplo2
datos<-c(115,232,181,161,155,137,165,171,139,130,406)
datos
boxplot(datos,horizontal = T,col="gold",type=2)
boxplot.stats(datos)

#ejercicio1(sin intervalos, 4 con)
#a
datos<-c(0, 2, 3, 2, 4, 1, 2, 3, 3, 0, 2, 6, 2, 1, 2, 3, 1, 2, 3, 1, 2, 7, 2, 1, 4, 2, 3, 3, 1, 0)
datos
t<-table(datos)
t
tabla<-data.frame(t)
tabla
tabla$datos
n=30
xi<-tabla$datos
fi<-tabla$Freq
FI<-cumsum(fi)
hi<-fi/n
HI<-cumsum(hi)
rdo<-data.frame(xi,fi,FI,hi,HI)
rdo

#b
barplot(t)
plot(xi,FI)

#c
rdo
rdo<-rdo[order(-rdo$fi),]
moda<-rdo[1,]$xi
moda
median(datos)
mean(datos)
summary(datos)

#d
rango<-max(datos)-min(datos)
rango
IQR(datos,type=2)
varianza<-var(datos)*(n-1)/n
varianza
desvitip<-sqrt(varianza)
desvitip
CV<-desvitip/mean(datos)
CV


#e
Q2<-quantile(datos,0.5,type=2)
median(datos)
D1<-quantile(datos,0.1,type=2)
D4<-quantile(datos,0.4,type=2)
D9<-quantile(datos,0.9,type=2)
P30<-quantile(datos,0.3,type=2)
P85<-quantile(datos,0.85,type=2)
D1
D4
D9
P30
P85

#f
skewness(datos)
pearson<-(mean(datos)-1)/desvitip
pearson
kurtosis(datos)

#g
boxplot(datos,horizontal=T,col="gold",type=2)
boxplot.stats(datos)



#ejercicio4
datos<-c(2.1,3.3,4.4,3.0,4.0,5.0,2.7,2.6,4.8,4.7,2.8,4.8,3.9,2.3,3.8,2.8,3.0,3.7,3.3,4.4,3.1,4.0,3.7,2.5,2.7,5.1,4.7)
datos
n<-length(datos)
n
min<-min(datos)
max<-max(datos)
nclases<-5
amp=(max-min)/nclases
amp
limites<-seq(min,max,amp)
limites
clases<-cut(datos,limites,right = FALSE, include.lowest = TRUE)
clases
t<-table(clases)
t
ta<-data.frame(t)
ta
cl<-ta$clases
fi<-ta$Freq
FI<-cumsum(fi)
hi<-fi/n
HI<-cumsum(hi)
rdo<-data.frame(cl,fi,FI,hi,HI)
rdo


#b
mean(datos)
median(datos)
desvitip<-sqrt(varianza <- var(datos)* (N-1)/N)
desvitip
moda<-names(table(datos))[which(table(datos)==max(table(datos)))] 
moda
table(datos)
