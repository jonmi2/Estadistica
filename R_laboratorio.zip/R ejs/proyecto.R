library(moments)
attach(PRECIOS_BILBAO)
preciosB = BILBAO

attach(PRECIOS_SEVILLA)
preciosS = SEVILLA
#IMPORTADOS LOS DATOS COMENZAMOS A ESTUDIARLOS

#media de las muestras en bilbao y en Sevilla
mediaMBio = mean(preciosB)
mediaMSev = mean(preciosS)

#número de datos en cada muestra
nBio = length(preciosB)
nSev = length(preciosS)

#rango de las dos muestra (el valor mayor menos el valor menor)
rangoBio = max(preciosB)-min(preciosB) 
rangoSev = max(preciosS)-min(preciosS)

#limites de cada muestra, tendremos 10 intervalos. Esto nos servirá para más adelante hacer la tabla de frecuencia con nuestros datos.
limitesBio <- seq(min(preciosB),max(preciosB),rangoBio/10)
limitesSev <- seq(min(preciosS),max(preciosB),rangoSev/10)

#dividimos nuestros datos en intervalos y despues hacemos la tabla
dataBio <- cut(preciosB,limitesBio,right = FALSE,include.lowest = TRUE)
dataBio
table(dataBio)
a<-as.data.frame(table(dataBio))
IntervalosBio<-a$dataBio

#frecuencia absoluta
Frecuencia.absBio<-a$Freq
sum(Frecuencia.absBio)

#frecuencia relativa
Frecuencia.relBio<-Frecuencia.absBio/110

#frecuencia absoluta acumulada
Frecuencia.absBio.acumBio<-cumsum(Frecuencia.absBio)

#frecuencia relatica acumulada
Frecuencia.relBio.acumBio<-cumsum(Frecuencia.relBio)

#tabla completa con los datos de Bilbao
TablaCompletaBio <- data.frame(IntervalosBio,Frecuencia.absBio,Frecuencia.absBio.acumBio,Frecuencia.relBio,Frecuencia.relBio.acumBio)
TablaCompletaBio$IntervalosBio <- format(TablaCompletaBio$IntervalosBio, scientific=FALSE)
TablaCompletaBio



#dividimos nuestros datos en intervalos y despues hacemos la tabla
dataSev <- cut(preciosS,limitesSev,right = FALSE,include.lowest = TRUE)
dataSev
table(dataSev)
a<-as.data.frame(table(dataSev))
IntervalosSev<-a$dataSev
IntervalosSev

#frecuencia absoluta
Frecuencia.absSev<-a$Freq
Frecuencia.absSev
sum(Frecuencia.absSev)


#frecuencia relativa
Frecuencia.relSev<-Frecuencia.absSev/110


#frecuencia absoluta acumulada
Frecuencia.abs.acumSev<-cumsum(Frecuencia.absSev)
Frecuencia.abs.acumSev


#frecuencia relativa acumulada
Frecuencia.relSev.acumSev<-cumsum(Frecuencia.relSev)
Frecuencia.relSev
Frecuencia.relSev.acumSev

#tabla completa con los datos de Sevilla
TablaCompletaSev <- data.frame(IntervalosSev,Frecuencia.absSev,Frecuencia.abs.acumSev,Frecuencia.relSev,Frecuencia.relSev.acumSev)
TablaCompletaSev

IntervalosBio
IntervalosSev

#diagramas de sectores
pie(table(dataBio))
pie(table(dataSev))

#histogramas
hist(preciosB)
hist(preciosS)

#diagramas de cajas, con esto podemos ver los valores atípicos
boxplot(preciosB,horizontal = TRUE)
boxplot(preciosS,horizontal = TRUE)

#estadisticos descriptivos de Bilbao.
#media (la hemos calculado antes)
mediaMBio
#mediana
medianaB<-median(preciosB)
#moda, haciendolo a mano da: 30 777.777
ModaB<-names(table(preciosB))[which(table(preciosB)==max(table(preciosB)))]
ModaB
#rango (lo hemos calculado antes) 
rangoBio
#rango intercuartilico
RICbio<-IQR(preciosB)
#Varianza
varBio<-var(preciosB)*(nBio-1)/nBio
#Desviacion tipica
desviBio<-sqrt(var(preciosB)*(nBio-1)/nBio)
#Coeficiente de variacion
CDVBio<-sqrt(var(preciosB)*(nBio-1)/nBio)/mean(preciosB)
#Cuartiles
cuartilBio<-quantile(preciosB)
cuartilBio
#Deciles
decilbio<-quantile(preciosB,probs=seq(0,1,0.1))
#Percentiles
percentilBio<-quantile(preciosB,probs=seq(0,1,0.01))


#estadisticos descriptivos de Sevilla
#media (la hemos calculado antes)
mediaMSev
#mediana
medianaS<-median(preciosS)
#moda, haciendolo a mano da: 7 285.185
ModaS<-names(table(preciosS))[which(table(preciosS)==max(table(preciosS)))]
ModaS
#rango (lo hemos calculado antes) 
rangoSev
#rango intercuartilico
RICsev<-IQR(preciosS)
#Varianza
varSev<-var(preciosS)*(nSev-1)/nSev
#Desviacion tipica
desviSev<-sqrt(var(preciosS)*(nSev-1)/nSev)
#Coeficiente de variacion
CDVsev<-sqrt(var(preciosS)*(nSev-1)/nSev)/mean(preciosS)
#Cuartiles
cuartilSev<-quantile(preciosS)
#Deciles
decilSev<-quantile(preciosS,probs=seq(0,1,0.1))
#Percentiles
percentilSev<-quantile(preciosS,probs=seq(0,1,0.01))


#YA QUE EL PVALOR ES CASI 0 SE PUEDE DECIR QUE LA DIFRENCIA DE MEDIAS NO ES 0 CON ROTUNDIDAD. POR TANTO SON DISTINTOS.
t.test(preciosB,preciosS, var.equal = T)

#YA QUE EL P VALOR ES CASI 0 CON TOTAL SEGURIDAD SE PODRIA DECIR QUE LA MEDIA DEL PRECIO DE BILBAO ES MAYOR QUE LA DE SEVILLA
t.test(preciosB,preciosS, alternative = "greater", conf.level = 0.95)

#YA QUE EL INTERVALO NO CONTIENE AL 0 Y ES MAYOR QUE 0 LA MEDIA DE BILBAO ES REALMENTE MAYOR QUE LA DE SEVILLA
intervaloDIFMEDIAS = t.test(preciosB,preciosS, conf.level = 0.95)$conf
intervaloDIFMEDIAS

#YA QUE EL INTERVALO SI CONTIENE AL 1 LA VARIANZA ES SIMILAR EN AMBAS CIUDADES, LO CUAL TIENE SENTIDO YA QUE ESTUDIAMOS EL
#EL MISMO PARAMETRO 
intervaloDIVVAR = var.test(preciosB, preciosS, conf.level = 0.95)$conf
intervaloDIVVAR
