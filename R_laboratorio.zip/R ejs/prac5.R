#ejemplo1: En una planta de potabilización se han medido durante 10 días los niveles de cloro de las aguas, en mg/L. Los resultados obtenidos son: 2.2,1.9,1.7,1.6,1.7,1.8,1.7,1.9,2.0,2.0. La distribución del nivel de cloro se considera normal.
#X = “Nivel de cloro en mg/L”. Calcula la estimación puntual de media y desviación tipica.
nivelcloro <- c(2.2,1.9,1.7,1.6,1.7,1.8,1.7,1.9,2.0,2.0)
nivelcloro
mean(nivelcloro)#Estimación puntual de la media
var(nivelcloro)#Estimación puntual de la varianza
sd(nivelcloro)#Estimación puntual de la desviación típica

#ejercicio6
muestra<- c(480,345,427,386,432,429,378,440,434,503,436,451,466,394,422,412,507,433,480,429)
length(muestra)
media<-mean(muestra)
desvi<-sd(muestra)
intervalo<-t.test(muestra,conf.level = 0.95)$conf
intervalo

#ejercicio4
n<-20
media<-10
varianza<-4
muestra<-rnorm(20,10,2)
#a
intervalo<-t.test(muestra,conf.level = 0.95)$conf
intervalo
#b
#nivel confianza 95%
intervalo95<-c(19*var(muestra)/qchisq(0.975,19),19*var(muestra)/qchisq(0.025,19))
intervalo95

#nivel confianza 99%
intervalo99<-c(19*var(muestra)/qchisq(0.995,19),19*var(muestra)/qchisq(0.005,19))
intervalo99


#ejercicio2
n<-200
defectuosas<-(15*n)/100
defectuosas
prop.test(defectuosas,n,conf.level=0.95)$conf


#ejercicio3
ICprop<-c((9/200-15/300)-qnorm(0.995,0,1)*sqrt((9/200)*(191/200)/200+(15/300)*(285/300)/300),(9/200-15/300)+qnorm(0.995,0,1)*sqrt((9/200)*(191/200)/200+(15/300)*(285/300)/300))
ICprop


#ejercicio9
biofiltros<-read.table("C:/Users/jonmi/Downloads/Biofiltros.txt")
biofiltros
